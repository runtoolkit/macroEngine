$function $(current_cmd)
