# ─────────────────────────────────────────────────────────────────
# macroengine:debug/dump_players
# Shows all player variables (player vars), PIDs and their states.
# Usage: /function macroengine:debug/dump_players
# ─────────────────────────────────────────────────────────────────

tellraw @s ["",{"text":"[MACROENGINE] ","color":"#00AAAA","bold":true},{"text":"━━━ Player State Dump ","color":"aqua"},{"text":"━━━━━━━━━━━━━","color":"#555555"}]
tellraw @s ["",{"text":" ","color":"#555555"},{"text":"players ","color":"white"},{"text":" → ","color":"#555555"},{"plain":true ,"storage":"macroengine:engine","nbt":"players","color":"green","italic":false}]
tellraw @s ["",{"text":" ","color":"#555555"},{"text":"pids ","color":"white"},{"text":" → ","color":"#555555"},{"plain":true ,"storage":"macroengine:engine","nbt":"player_pids","color":"aqua","italic":false}]
tellraw @s ["",{"text":" ","color":"#555555"},{"text":"perms ","color":"white"},{"text":" → ","color":"#555555"},{"plain":true ,"storage":"macroengine:engine","nbt":"permissions","color":"yellow","italic":false}]
tellraw @s ["",{"text":"[MACROENGINE] ","color":"#00AAAA","bold":true},{"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"#555555"}]